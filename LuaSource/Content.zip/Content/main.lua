
if _VERSION == "Lua 5.3" then
    function table.maxn(t)
        return #t
    end

    function unpack( ... )
        return table.unpack(...)
    end

    function loadstring( ... )
        return load(...)
    end
end

function Fire()
end

function main(IsMannual)
    -- debug begin
    --require("frame.debug.LuaPanda").start()
    -- end
    require "frame.initrequire"
    require "timermgr"
    collectgarbage("setpause", 200)
    collectgarbage("setstepmul", 5000)
    require "frontend.init"

    require "util.automationtesthelper"
end

