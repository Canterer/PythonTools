
local ESlateVisibility = import "ESlateVisibility"
local basewidget = require "frame.widget.basewidget"
BaseView = Inherit(basewidget)

function BaseView:Ctor()
	
	rawset(self,"m_ChildWigets" ,{})
end

function BaseView:OnInit(Name)
	
end

function BaseView:Destruct( )
	rawset(self,"m_ChildWigets" ,{})
end

function BaseView:GroupTab(...)
	self.m_GroupTabs = self.m_GroupTabs or {}
	local Tabs = {...}
	table.insert(self.m_GroupTabs, Tabs)
	local GroupId = #self.m_GroupTabs+1
	local OnCheckFunc = nil
	local TabsHandle = {}
	TabsHandle.Tabs = Tabs
	function TabsHandle:Call(...)
		OnCheckFunc = InsCallBack(...)
		return self
	end
	function TabsHandle:Switch(EventName, HitOperator, OtherOperation)
		TabsHandle.HitOperator = HitOperator
		TabsHandle.OtherOperation = OtherOperation
		local function f(self, IndexChecked)
			TabsHandle:CheckByIndex(IndexChecked)
		end
		for Index, Tab in ipairs(Tabs) do
			Tab:Event(EventName, f, Tab, Index)
		end
		return self
	end
	function TabsHandle:Destroy()
	end
	function TabsHandle:RemoveAllEvent()
		for _, Tab in ipairs(self.Tabs) do
			Tab:RemoveAllEvent()
		end
	end
	function TabsHandle:CheckByIndex(IndexChecked, ...)
		for ii, Tab in ipairs(Tabs) do
			if ii == IndexChecked then
				Tab[TabsHandle.HitOperator](Tab)
				if OnCheckFunc then
					OnCheckFunc(IndexChecked, ...)
				end
			else
				Tab[TabsHandle.OtherOperation](Tab)
			end 
		end
	end
	function TabsHandle:InitCheckState(IndexChecked)
		for ii, Tab in ipairs(Tabs) do
			if Tab.TabTypeIndex == IndexChecked then
				Tab[TabsHandle.HitOperator](Tab)
			else
				Tab[TabsHandle.OtherOperation](Tab)
			end
		end
	end
	return TabsHandle
end

function BaseView:CreateChild(LuaClassPath, ...)
	if type(LuaClassPath) == "string" then
		local ins = require(LuaClassPath)
		if type(ins) == "table" then
			local BpClassPath = rawget(ins,"BpClassPath")
			if BpClassPath ~= nil then
				local widget = UMG.CreateWidget(BpClassPath, self)
				if widget ~= nil and type(widget) == "userdata" then
					return ins:NewOn(widget)
				elseif type(widget) == "table" then
					return widget
				end
			end
		end
		
	elseif type(LuaClassPath) == "table" then
		local Ins = LuaClassPath:New(self, ...)
		Ins:SetParent(self)
		return Ins
	elseif type(LuaClassPath) == "userdata" then
		local BpClass = LuaClassPath
		local inscpp = UMG.CreateWidget(BpClass,self)
		local Ins = BaseView:NewOn(inscpp, ...)
		Ins:SetParent(self)
		return Ins
	end
	assert(false)
end

function BaseView:AsynCreateChild(LuaClassPath, ...)
	local CoroutineHandle = CoroutineMgr:Get():GetHandle()
	if CoroutineHandle and CoroutineHandle:IsValid() then
		if type(LuaClassPath) == "string" then
			local Ins = require(LuaClassPath):AsynNew(self, ...)
			Ins:SetParent(self)
			return Ins
		elseif type(LuaClassPath) == "table" then
			local Ins = LuaClassPath:AsynNew(self, ...)
			Ins:SetParent(self)
			return Ins
		else
			assert(false)
		end
	else
		-- 退化为同步方式
		return self:CreateChild(LuaClassPath, ...)
	end
end


function BaseView:AddChild_CallFromChild(ChildIns)
	self.m_ChildWigets[ChildIns] = ChildIns
end

function BaseView:NewInsByBpClass(BpClass, Outer, ... )
	assert(BpClass)
	local inscpp = UMG.CreateWidget(BpClass,Outer)
	assert(inscpp)
	local ins = inscpp
	if type(inscpp) == "userdata" then
		ins = self:NewOn(ins, ...)
	end
	return ins
end

local weakmeta = {__mode = "kv"}
local CachedClass = setmetatable({}, weakmeta)
function BaseView:GetBpClass( Outer, BpClassPath)
	local BpClass = CachedClass[BpClassPath]
	if not BpClass then
		BpClass = UUserWidget.LoadClass(Outer, BpClassPath)
		CachedClass[BpClassPath] = BpClass
	end
	return BpClass
end

function BaseView:New(Outer, ...)
	assert(type(Outer) == "table" )
	assert(self.BpClassPath and self.BpClassPath ~= "")
	LogDisplay("BaseView:New", self.BpClassPath)
	local BpClass = self:GetBpClass(Outer, self.BpClassPath)
	return self:NewInsByBpClass(BpClass, Outer, ...)
end

function BaseView:AsynNew(Outer, ...)
	assert(type(Outer) == "table" )
	assert(self.BpClassPath and self.BpClassPath ~= "")
	LogDisplay("BaseView:AsynNew", self.BpClassPath)
	local BpClass = CoroutineUtil.LoadAsset(self.BpClassPath)
	return self:NewInsByBpClass(BpClass, Outer, ...)
end

function BaseView:SetParent(Parent)
	self.m_Parent = Parent
	Parent:AddChild_CallFromChild(self)
end


function BaseView:SafeWidgetFunCall(WidgetName, FuncName, ...)
	if self:GetWidgetFromName(WidgetName) then
		local widget = self:Wnd(WidgetName)
		widget[FuncName](widget, ...)
	end
end


function BaseView:AsyncLoad(ObjectSoftPath, ...)
	return RequestAsyncLoad(ObjectSoftPath, InsCallBack(...))
end

function BaseView:AsyncLoadImage(ObjectSoftPath, ...)
	return RequestAsyncLoadImage(ObjectSoftPath, InsCallBack(...))
end

function BaseView:AsynSetImage(ResourceId, ResourceType, ...)
	if self.TShared_handle then
		local handle = self.TShared_handle:Get()
		if handle then
			handle:CancelHandle()
		end
    end
	ResourceId = tostring(ResourceId)
	local AssertPath = NZAssetManager.Get():GetIconSpritePath(ResourceId, ResourceType)
	self.TShared_handle = self:AsyncLoadImage(AssertPath, self.AsynLoadImageCallBack, self, ...)
end

function BaseView:AsynLoadImageCallBack(Sprite)
	if Sprite ~= nil and self.Brush ~= nil then 
		local Brush = FSlateBrush.Temp()
		Brush.ResourceObject = Sprite
		Brush.ImageSize = self.Brush.ImageSize
		self:SetBrush(Brush)
		self:SetVisibility(ESlateVisibility.HitTestInvisible)
    end
end

return BaseView
