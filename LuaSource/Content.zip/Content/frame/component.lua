Component = {}

function Component.Attach(ins,component_path)
    if ins == nil then return end
    if type(ins) ~= "table" then return end
    
    local components = rawget(ins,"_components_")
    if components == nil then
        components = {}
        rawset(ins,"_components_",components)
    end
    local component = require(component_path)
    
    component.GetOwner = function()
        return ins
    end
    component.On = function(self,...)
        local handle = GlobalEvent.On(...)
	    handle.SetOwner(ins)
	    self._event_handles_[handle] = true
	    return handle
    end
    component:Ctor()
    table.insert( components, component)
end


function Component.Release()
    
end

function Component.Inherit()
    local o = {
        _event_handles_ = {}
    }
    return o
end
return Component