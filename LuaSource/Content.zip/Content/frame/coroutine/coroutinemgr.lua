local Handle = Inherit(LuaClassBase)

local weakmeta = {__mode = "v"}

function Handle:NewIns(mgr,newcoroutine)
	local o = Inherit(Handle);
	ConstructRecursively(o,o,mgr,newcoroutine)
	return o
end

function Handle:Ctor(mgr, newcoroutine)
	self.mgr = mgr
	self.coroutine = newcoroutine
end

function Handle:Resume( ... )
	if self.mgr:Exist(self) then
		local result = {coroutine.resume(self.coroutine, ...)}
		if coroutine.status(self.coroutine) == "dead" then
			self:Destroy()
		end
		ensure(result ~= nil)
		ensure(result[1], result[2])
		return unpack(result, 1, 10)
	end
end

function Handle:Yield( ... )
	-- if self.mgr:Exist(self) then
		return coroutine.yield(...)
	-- end
end

function Handle:GetStatus()
	ensure(self.coroutine ~= nil, "self.coroutine is nil")
	return coroutine.status(self.coroutine)
end

function Handle:IsDead()
	return self:GetStatus() == "dead"
end


function Handle:Destroy()
	self.m_NotValid = true
	self.mgr:DestroyHandle(self)
	self.coroutine = nil
end

function Handle:IsValid()
	return self.m_NotValid ~= true
end

CoroutineMgr = Inherit(Singleton)
function CoroutineMgr:Ctor()
	self.handles={}
	self._coroutine_ = {}
end

function CoroutineMgr:DestroyHandle(handle)
	self.handles[handle] = nil
	self.handles[handle.coroutine] = nil
end

function CoroutineMgr:Exist(co_or_handle)
	return self.handles[co_or_handle] ~= nil
end

function CoroutineMgr:GetHandle()
	local co = coroutine.running()
	return co and self.handles[co]
end

function CoroutineMgr:GetHandleOfCo(co)
	ensure(co ~= nil, "co is nil")
	return co and self.handles[co]
end


function CoroutineMgr:Create(func)
	local newcoroutine = coroutine.create(func)
	local newhandle = Handle:NewIns(self, newcoroutine)
	self.handles[newcoroutine] = newhandle
	self.handles[newhandle] = newcoroutine
	return newhandle
end

function CoroutineMgr:Run(func,...)
	local handle = CoroutineMgr:Get():Create(func)
	
	return handle, handle:Resume(...)
end

return CoroutineMgr