
local CppInsStr = "__cppinst"

local function __indexcpp(t,k)
	local ins = rawget(t,CppInsStr)
	if ins == nil then 
		return nil
	end
	if type(ins) ~= "userdata" then
		return nil
	end
	local v = ins[k]
	if type(v) == "function" then
		return function(self,...) 
			local ins = rawget(self,CppInsStr)
			return v(ins,...)
		end
	end
	return v
end

local function __newindexcpp(t,k,v)

	local ins = rawget(t,CppInsStr)
	if type(ins) == "userdata" then 
		local ins_v = ins[k]
		if ins_v == nil then
			rawset(t,k,v)
		else
			ins[k] = v
		end
	end
end

local function Initialize(self)
	local inited = rawget(self,"_initialize_")
	if not inited then
		rawset(self,"_initialize_",true)
		rawset(self,"NewOn",nil)
		ConstructRecursively(self,self)
	end
end

local function __gccpp(t)
	if t == nil then return end
	if type(t) ~= "table" then return end
	
	DestructRecursively(t,t)

	local inscpp = rawget(t,CppInsStr)
	if inscpp ~= nil then
		rawset(t,CppInsStr,nil)
	end
end

local function NewOn(self,inscpp, ...)
	local ins = {}
	for k,v in pairs(self) do
		if type(v) == "function" and k ~= "Ctor"  and k ~= "Destruct" and k ~= "NewOn" then 
			rawset(ins,k,v)
		end
	end
	rawset(ins,"_meta_",self)
	rawset(ins,CppInsStr,inscpp)

	ConstructRecursively(self,ins)
	
	rawset(ins,"_initialize_",true)
	setmetatable(ins, {__index = __indexcpp,__newindex = __newindexcpp,__gc = __gccpp})
	return ins
end


function DefLuaClass(BaseClass)
	local TheClass = {}
	for k,v in pairs(BaseClass) do
		if type(v) == "function" and k ~= "Ctor" and k ~= "Destruct" and not TheClass[k] then
			rawset(TheClass,k,v)
		end
	end
	rawset(TheClass,"_meta_",BaseClass)
	rawset(TheClass,"Initialize",Initialize)
	rawset(TheClass,"NewOn",NewOn)
	
	return TheClass
end

local function GetObject(self)
	local name = rawget(self,"_singleton_name_")
	if name ~= nil then
		local singletons = rawget(CppSingleton,"_singletons_")
		if singletons ~= nil then
			return rawget(singletons,name)
		end
	end
end

CppSingleton = {}

function CppSingleton.New(BaseClass,Name)
    local singletons = rawget(CppSingleton,"_singletons_")
    if singletons == nil then 
        singletons = {}
        rawset(CppSingleton,"_singletons_",singletons)
    end
    local singleton = rawget(singletons,Name)

    if singleton == nil then
        singleton = {}
        for k,v in pairs(BaseClass) do
            if type(v) == "function" and k ~= "Ctor" and k ~= "Destruct" and not singleton[k] then
                rawset(singleton,k,v)
            end
        end
        rawset(singleton,"_singleton_name_",Name)
        rawset(singleton,"_luains_",singleton)
		rawset(singletons,Name,singleton)
	else
		print("find singleton")
    end

    return singleton
end

function CppSingleton.GetLuaByIns(cppins) 
	local singletons = rawget(CppSingleton,"_singletons_")
	if singletons == nil then 
		return nil
	end
	for k,v in pairs(singletons) do 
		if type(v) == "table" then
			if type(cppins) == "userdata" then
				local ins = rawget(v,CppInsStr)
				if ins == cppins then 
					return v
				end
			elseif type(cppins) == "string" then
				local name = rawget(v,"_singleton_name_")
				if name == cppins then 
					return v
				end
			end
		end
	end

	return nil
end

function CppSingleton.Release(self)
	local singletons = rawget(CppSingleton,"_singletons_")
	if singletons == nil then 
		return
	end
	local singleton_name = rawget(self,"_singleton_name_")
	if singleton_name == nil then
		return
	end
	local singleton = rawget(singletons,singleton_name)
	assert(singleton ~= nil and singleton == self, "check here...")
	rawset(singletons,singleton_name,nil)
	rawset(singleton,"_luains_",nil)
end

function CppSingleton.Find(name)
	local singletons = rawget(CppSingleton,"_singletons_")
	if singletons ~= nil then
		return rawget(singletons,name)
	end
	
end

function DefLuaObject(BaseClass,Name)
	
	local TheObject = CppSingleton.New(BaseClass,Name)
	
	rawset(TheObject,"_meta_",BaseClass)
	rawset(TheObject,"Initialize",Initialize)
	rawset(TheObject,"Get",GetObject)
	return TheObject
end


CppObjectBase = {}

function CppObjectBase:Ctor()
end

function CppObjectBase:Timer(...)
	return TimerMgr:Get():On(...)
end

function CppObjectBase:Destruct()
	CppSingleton.Release(self)
end

function CppObjectBase:OnDestroy()
	DestructRecursively(self, self)
end

function CppObjectBase:CppIns()
	return rawget(self,CppInsStr)
end

return CppObjectBase