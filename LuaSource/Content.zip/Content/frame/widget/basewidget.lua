local basewidget = DefLuaClass(CppObjectBase)
local ESlateVisibility = import "ESlateVisibility"


function basewidget:Ctor()
	rawset(self,"m_delegates", {})
	rawset(self,"m_Widgets", {})
end

function basewidget:Destruct()
	self:RemoveAllEvent()
	rawset(self,"m_delegates", nil)
	rawset(self,"m_Widgets", nil)
end

function basewidget:Hidden()
end

local WidgetComponents = {
	Image = require "frame.widget.image"
}
local function AttachWidgetComponent(ins,class_name)
	local component = rawget(WidgetComponents,class_name)
	if component ~= nil and type(component) == "table" then
		for k,v in pairs(component) do
			if type(v) == "function" and rawget(ins,k) == nil then
				rawset(ins,k,v)
			end
		end
	end
end

function basewidget:Wnd(Name)
	assert(Name)
	local find_widget = rawget(self.m_Widgets, Name)
	if find_widget ~= nil then 
		return find_widget
	end
	find_widget = self:FindWidget(Name)
	
	if type(find_widget) == "userdata" then
		local class_name = tostring(find_widget:GetClassName())
		find_widget = basewidget:NewOn(find_widget)
		AttachWidgetComponent(find_widget,class_name)
		-- add other component
	end
	rawset(self.m_Widgets,Name,find_widget)
	return find_widget
end

function basewidget:Hidden()
	self:SetVisibility(ESlateVisibility.Hidden)
end

function basewidget:Collapsed()
	self:SetVisibility(ESlateVisibility.Collapsed)
end

function basewidget:Visible()
	self:SetVisibility(ESlateVisibility.Visible)
end

function basewidget:SelfHitTestInvisible()
	self:SetVisibility(ESlateVisibility.SelfHitTestInvisible)
end

function basewidget:Event(delegateName, callback, ...)
	local delegates = self.m_delegates
	local DelegateIns = rawget(delegates,delegateName)
	if not DelegateIns then
		DelegateIns = self[delegateName]
        if not DelegateIns then
            a_(delegateName.." not exists")
        end
		delegates[delegateName] = DelegateIns
	end
	-- 多播
	if DelegateIns.Add then
		return delegates[delegateName]:Add(InsCallBack(callback, ...))
	-- 单播
	elseif DelegateIns.Bind then
		return delegates[delegateName]:Bind(InsCallBack(callback, ...))
	end
end

function basewidget:RemoveEvent(delegateName)
	local DelegateIns = self[delegateName]
	if DelegateIns then
		if DelegateIns.Clear then
			DelegateIns:Clear()
		end
	end
end

function basewidget:RemoveEventByHandle(delegateName, r)
	self.m_delegates = self.m_delegates or {}
	local delegates = self.m_delegates
	if delegates[delegateName] then
		delegates[delegateName]:Remove(r)
	end
end

function basewidget:RemoveAllEvent( )
	if self.m_delegates ~= nil then
		for name in pairs(self.m_delegates) do
			self:RemoveEvent(name)
		end
	end	
end

return basewidget