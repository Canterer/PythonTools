local image = {}

function image:AsynSetImage(ResourceId,ResourceType,...)
    
    if self.Async_Handle then
		  self.Async_Handle:CancelHandle()
    end

    local NZAssetManager = import "NZAssetManager"
    ResourceId = tostring(ResourceId)
    local AssertPath = NZAssetManager.Get():GetIconSpritePath(ResourceId, ResourceType)

    self.Async_Handle = RequestAsyncLoadImage(AssertPath, InsCallBack(self.AsynLoadImageCallBack,self,...))
end

function image:AsynLoadImageCallBack(Sprite)
    if Sprite ~= nil and self.Brush ~= nil then 
        local FSlateBrush = import "SlateBrush"
		    local Brush = FSlateBrush()
		    Brush.ResourceObject = Sprite
		    Brush.ImageSize = self.Brush.ImageSize
		    self:SetBrush(Brush)
		    self:SetVisibility(ESlateVisibility.HitTestInvisible)
    end
end

return image