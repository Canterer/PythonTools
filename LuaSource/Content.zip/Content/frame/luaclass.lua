
local CtorStr = "Ctor"

function ConstructRecursively(theclass, ins,...)
	if theclass == nil then return end
	local super = rawget(theclass,"_meta_")
	if super then
		ConstructRecursively(super, ins, ...)
	end
	local Ctor = rawget(theclass, CtorStr)
	if Ctor then Ctor(ins, ...) end
end

DestoryStr = "Destruct"
function DestructRecursively(theclass,ins)
	if theclass == nil then return end
	local super = rawget(theclass,"_meta_")
	if super then
		DestructRecursively(super, ins)
	end
	local Destory = rawget(theclass, DestoryStr)
	if Destory then Destory(ins) end
end


function Inherit(BaseLuaClass)
    local o = {}
    for k,v in pairs(BaseLuaClass) do
        if type(v) == "function" and k ~= CtorStr and k ~= DestoryStr  then
            rawset(o,k,v)
        end
    end
    rawset(o,"_meta_",BaseLuaClass)
    return o
end


LuaClassBase = {}

function LuaClassBase:Ctor()
end

Singleton = Inherit(LuaClassBase)


function Singleton:Ctor()
    
end

function Singleton:Get()
    local ins = rawget(self,"_luains_")
    if ins == nil then 
        rawset(self,"_luains_",self)
        ins = self
        ConstructRecursively(self,ins)
    end
    return ins
end

