

local this = {}

this._instance = nil

function this.Get()
    if this._instance == nil then 
        this._instance = setmetatable({},{__index = this})
    end
    return this._instance
end

function this:GetIconSpritePathFromCache(ResourceId, ResourceType,IconType)
    if self._IconCache == nil then 
        self._IconCache = {}
    end

    if self._IconCache[IconType] == nil then 
        self._IconCache[IconType] = {}
    end

    local _cache = self._IconCache[IconType]

    if _cache[ResourceType] ~= nil and _cache[ResourceType][ResourceId] ~= nil then 
        return _cache[ResourceType][ResourceId]
    end 

    if self._IconCache[IconType][ResourceType] == nil then 
        self._IconCache[IconType][ResourceType] = {}
    end

    return nil
end


function this:GetIconSpritePath(ResourceId, ResourceType)
    
    local res = self:GetIconSpritePathFromCache(ResourceId,ResourceType,"icon")
    if res == nil then 
        res = FNZLuaUIHelper.GetIconSpritePath(ResourceId, ResourceType)

        self._IconCache['icon'][ResourceType][ResourceId] = res 

    end 

    return res
end


function this:GetIconElseSpritePath(ResourceId, ResourceType)
    local res = self:GetIconSpritePathFromCache(ResourceId,ResourceType,"iconelse")
    if res == nil then 
        res = FNZLuaUIHelper.GetIconElseSpritePath(ResourceId, ResourceType)
        self._IconCache['iconelse'][ResourceType][ResourceId] = res 
    end 

    return res
end

return this