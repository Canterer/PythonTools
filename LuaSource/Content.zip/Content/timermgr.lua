
TimerMgr = Inherit(Singleton)
local weakmeta = {__mode = "v"}

local TimerHandlerClass = {}
function TimerHandlerClass:Time(InTime)
    FLuaTimerHelper.SetRate(self.DelegateID,InTime)
    return self;
end

function TimerHandlerClass:SetOwner(ObjectBaseOwner)
    self.OwnerTable[1] = ObjectBaseOwner
    return self
end

function TimerHandlerClass:Bound()
    return self
end

function TimerHandlerClass:Fire()
    return self
end


function TimerHandlerClass:Num(InNum)
    FLuaTimerHelper.SetNum(self.DelegateID,InNum)
    return self
end

function TimerHandlerClass:Destroy()
    FLuaTimerHelper.ClearTimer(self.DelegateID)
    
    local Owner = self.OwnerTable[1]
    if Owner and Owner['RemoveTimerHandle'] then
		Owner:RemoveTimerHandle(self)
    end
    
    self.DelegateID = -1
    self.Func = nil
    self.Params = nil
    self.Mgr = nil
end

function TimerHandlerClass:Callback()
    self.Func(table.unpack(self.Params))
end

TimerMgr.TimerHandlerClass = TimerHandlerClass

function TimerMgr:On(InFunc,...)
    local TimerHandle = setmetatable({}, {__index = TimerMgr.TimerHandlerClass})
    TimerHandle.Mgr = self
    TimerHandle.Func = InFunc
    TimerHandle.Params = table.pack(...)
    TimerHandle.OwnerTable = setmetatable({...}, {__mode = "kv"})
    local f = function()
        Xpcall(TimerHandlerClass.Callback,TimerHandle)
    end
    local TimerDelegate = FLuaTimerHelper.SetTimer(f)
    TimerHandle.DelegateID = TimerDelegate
    return TimerHandle
end
