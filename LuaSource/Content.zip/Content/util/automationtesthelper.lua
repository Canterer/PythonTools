

function AutomationRequestCreateRoom( MapId, GameType, ModeType, submode_type, PlayerMaxCount,
    ObserverMaxCount, RoomName, PasswordText, PasswordHidden)
    local logstr = "MapID "..MapId.." GameType "..GameType.." ModeType "..ModeType
    LogDisplay("[elvis]", logstr)
    local Req = pb.CSRoomCreateRoomReq:New()
    Req.map_id = MapId or MatchMapIDEnums.MATCH_MAPID_SAKURA_CITY
    Req.game_type = GameType or MatchGameTypeEnums.MATCH_GAME_TYPE_PVE
    Req.mode_type = ModeType or MatchModeTypeEnums.MATCH_MODETYPE_GAMELAND
    Req.submode_type = submode_type or MatchSubModeTypeEnums.MATCH_SUBMODETYPE_EASY
    Req.player_max_count = PlayerMaxCount or 4--8
    Req.observer_max_count = ObserverMaxCount or 0
    Req.customroom_name = RoomName or "测试房间"
    Req.customroom_password = PasswordText 
    Req.password_hidden = PasswordHidden or false
    Req.obseat_lock = true
    Req:Send()
end

function AutomationRequestStartBattle(CustomroomId, IsStart)
    local logstr = "CustomroomId "..CustomroomId
    LogDisplay("[elvis]", logstr)
    local Req = pb.CSRoomStartMatchReq:New()
    Req.customroom_id = CustomroomId
    Req.start_match = IsStart
    Req:Send()
end