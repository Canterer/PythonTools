

function DiscardOldExistTable()
  	local registry = debug.getregistry()["_existuserdata"]
    local newmeta = {__mode = "kv"}
    local newexist = {}
    for k, v in pairs(registry) do
        newexist[k] = v
    end
    setmetatable(newexist, newmeta)
    debug.getregistry()["_existuserdata"] = newexist
end 

function GetWorld()
    return ProtoMgr:Get():GetWorld()
end
local SingletonCached={}

function GetCppSingleton(Ins, DataClassName)
    if type(Ins) == "string" then
        return GetCppSingleton(nil, Ins)
    end
    local SingletonIns = SingletonCached[DataClassName]
    if not SingletonIns then
        local SingletonClass = import(string.sub(DataClassName,2)) 
        local UE4Singletons = import "E4Singletons"
        SingletonIns = UE4Singletons.GetSingletonImpl(SingletonClass, Ins, true, nil)
        SingletonCached[DataClassName] = SingletonIns
        assert(SingletonIns ~= nil)
    end
    return SingletonIns
end

function GetOnlineMsgHandler(ClassName)
    local SingletonIns = SingletonCached[ClassName]
    local Online = require "frontend.online.online"
    if not SingletonIns then
        import (ClassName)
        local OnlineConnectService = Online.GetOnlineService(Online.EOnlineService_Connect)
        SingletonIns = OnlineConnectService:GetOnlineMsgHandler(GetWorld(), _G[ClassName].Class())
        SingletonCached[ClassName] = SingletonIns
    end
    return SingletonIns
end

function GetLanguageData(str)
    assert(type(str) == "string")
    local UNZLanguageData = import "UNZLanguageData"
    local LanguageData = GetCppSingleton(nil, "UNZLanguageData")
    return LanguageData:GetLanguageByKey(str)
end

function RequestAsyncLoad(ObjectSoftPath, CallBack)
    assert(type(CallBack) == "function")
    if type(ObjectSoftPath) == "string" then
        local Temp =  FSoftObjectPath.New()
        Temp:SetPath(ObjectSoftPath) 
        ObjectSoftPath = Temp
    end
    local StreamableHandle = FNZLuaUIHelper.RequestAsyncLoad(ObjectSoftPath, CallBack)
    return StreamableHandle
end

function RequestAsyncLoadImage(ObjectSoftPath, CallBack)
    assert(type(CallBack) == "function")
    
    local StreamableHandle = FNZLuaUIHelper.RequestAsyncLoad(ObjectSoftPath, CallBack)
    return StreamableHandle
end

function GetErrorTextByKey(errorCode)
    assert(type(errorCode) == "number")
    local errorcodeData = GetCppSingleton(nil, "UNZMsgErrorCodeData")
    return errorcodeData:GetErrorTextByKey(errorCode)
end

-- 判断不同字节长度的字符串显示实际所占空间
-- 输入需要判断字符串:inputstr和最长显示字节长度:maxLen(可以不输入)
-- 输出字节长度:width和符合显示长度的字符串:newStr
function string.widthSingle(inputstr,maxLen)
    -- 计算字符串宽度
    -- 可以计算出字符宽度，用于显示使用
   local lenInByte = #inputstr
   local newStr = "";
   local width = 0
   local OneByteWidth = 0
   local TwoByteWidth = 0
   local ThreeByteWidth = 0
   local FourByteWidth = 0
   local i = 1
   while (i<=lenInByte) 
    do
        local curByte = string.byte(inputstr, i)
        local byteCount = 1;
        if curByte > 0 and curByte <= 127 then
            byteCount = 1                                           --1字节字符
            OneByteWidth = OneByteWidth + 1;
        elseif curByte >= 192 and curByte < 223 then
            byteCount = 2                                           --双字节字符
            TwoByteWidth = TwoByteWidth + 1;
        elseif curByte >= 224 and curByte < 239 then
            byteCount = 3                                           --汉字
            ThreeByteWidth = ThreeByteWidth + 1;
        elseif curByte >= 240 and curByte <= 247 then
            byteCount = 4                                           --4字节字符
            FourByteWidth = FourByteWidth + 1;
        end

        local char = string.sub(inputstr, i, i+byteCount-1)                                                      
        
        i = i + byteCount                                 -- 重置下一字节的索引
        width = width + 1                                 -- 字符的个数（长度）
        if maxLen then
            if width <= maxLen then
                newStr = newStr .. char
            end
        else
            newStr = newStr .. char
        end
    end
    return width,newStr
end