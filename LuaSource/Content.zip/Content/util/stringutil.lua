StringUtil = {}
function StringUtil.ReplaceEscapedCharWithChar(str)
	return string.gsub(str, "\\n", "\n")
end

function StringUtil.Trim(str)
	return (str:gsub("^%s*(.-)%s*$", "%1"))
end

function StringUtil.Split(str, sep)
	if str == nil then return nil end
	local str1, str2 = string.match(str, "(.-)"..sep.."(.*)")
	if str1 == nil then return str end
	return str1, StringUtil.Split(str2, sep)
end

function StringUtil.tostring(t)
	local mark   = {}
	local assign = {}
 
	local function serialize(tbl, parent)
		mark[tbl] = parent
		local tmp = {}
		for k, v in pairs(tbl) do
			local typek = type(k)
			local typev = type(v)

			local key = typek == "number" and "[" .. k .."]" or k

			if typev == "table" then
				local dotkey = parent .. (typek == "number" and key or "." .. key)
				if mark[v] then
					table.insert(assign, dotkey .. "=" .. mark[v])
				else
					if typek == "number" then
						table.insert(tmp, serialize(v,dotkey))
					else
						table.insert(tmp, key .. "=" .. serialize(v, dotkey))
					end
				end
			else
				if typev == "string" then
					v = string.gsub(v, "\n", "\\n")
					if string.match( string.gsub(v,"[^'\"]",""), '^"+$' ) then
						v = "'" .. v .. "'"
					else
						v = '"' .. v .. '"'
					end
				else
					v = tostring(v)
				end

				if typek == "number" then
					table.insert(tmp, v)
				else
					table.insert(tmp, key .. "=" .. v)
				end
			end
		end
		return "{" .. table.concat(tmp, ",") .. "}"
	end
 
	return serialize(t, "ret") .. table.concat(assign," ")
end

function StringUtil.loadstring(str)
	local chunk = loadstring("do local ret = " .. str .. " return ret end")
	if chunk then
		return chunk()
	end
end

--[[
Lua里实现了两个全局函数，NSLOCTEXT(SpaceName, Key, Value)跟LOCTEXT(Key, Value)，它们的效果跟c++里对应的两个宏的效果是一样的。
默认值是Value，设置了语言之后，会到翻译表里查找对应显示的值，界面上的STextBlock控件会实时变成对应的语言。
参数SpaceName，Key，Value都必须是明文，不能是变量。UE4有一个工具去扫描分析文本，把符合这些格式的文本提取出来，放到一张表里，然后我们对应不同语言来翻译Value。
对于需要格式化的字符串，也是类似的，用上面两个方法获得一个FText指针之后，用
FText.Format方法，例如
local text = NSLOCTEXT("Example", "keytest", "SomeValue {0}, {1}")
local arg1 = NSLOCTEXT("Example", "arg1", "a")
local arg2 = NSLOCTEXT("Example", "arg2", "b")
local result = text:Format(arg1,arg2)
在lua里设置语言使用UKismetInternationalizationLibrary库，例如UKismetInternationalizationLibrary.SetCurrentCulture("zh", true)，zh是中文的简写。
]]

local FText_cached = {}
function NSLOCTEXT(NameSpace, Key, Value)
	return tostring(Value)
end

function NSLOCTEXT(NameSpace,Key,Value)
	return tostring(Value)
end

-- function LOCTEXT(Key, Value)
-- 	return NSLOCTEXT("LuaText", Key, Value)
-- end

return StringUtil