
local function write(str)
    if _WITH_EDITOR == 1 then
        local logfile = io.open(_luadir.."/log.txt", "a")
        if logfile then
            logfile:write(str)
            logfile:flush()
            logfile:close()
        end
    end
    print(str)
    
end
function Q_(t)
    a_(require "inspect"(t))    
end
function q_(...)
    a_(...)
end
function a_(...)
    local str = ""
    local temp = {...}
    for i = 1, table.maxn(temp) do
        str = str..tostring(temp[i]).."  "
    end
    str = str.."\n"
    --ULuautils.log(str)
    write("["..tostring(os.date()).."] ".. str)
end

function LogDisplay(...)
    local str = ""
    local temp = {...}
    for i = 1, table.maxn(temp) do
        str = str..tostring(temp[i]).."  "
    end
    str = str.."\n"
    write(str)
end

function A_( ... )
    local str = ""
    local temp = {...}
    for i = 1, table.maxn(temp) do
        str = str..tostring(temp[i]).."  "
    end
    -- if G_GameStatics.GameMode then
    --    UKismetSystemLibrary.PrintString(nil, str)
    -- end
    str = "["..tostring(os.date()).."] "..str
    str = str.."\n"
    write(str)
end

function errhandle(err)
    q_(err)
end

function DebugLog(err)
    q_(err)
end

function Xpcall(f,...)
    xpcall(f, errhandle,...)
end

function ensure(isTrue, msg)
    if not isTrue then
        q_(msg)
        error(msg)
    end
end